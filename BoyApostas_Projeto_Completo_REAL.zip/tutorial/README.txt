1. Extraia o projeto
2. Suba no GitHub ou Railway
3. Configure o Telegram Bot
